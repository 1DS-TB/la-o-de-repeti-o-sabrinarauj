num = int(input("Digite um número para visualizar a tabuada: \n"))

for contador in range(10):
     print(num,"x",contador, "=" ,num * contador)