""" num = int(input("Digite um número inteiro (positivo): \n"))
i = 0

while i < num:
    i = i + num
    print(i) --> Corrigir essa questão """
